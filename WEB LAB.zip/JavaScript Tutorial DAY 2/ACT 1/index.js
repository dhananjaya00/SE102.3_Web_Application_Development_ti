const date = new Date();
document.getElementById('date').innerHTML = date;
