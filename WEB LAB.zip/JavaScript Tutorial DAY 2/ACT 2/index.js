let video = document.getElementById('video');

function play () {
    video.play();
}
video.addEventListener("mouseover", playVideo);
