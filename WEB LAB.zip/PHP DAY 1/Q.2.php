<?php
    for($x = 5; $x <= 15; $x+=3 ) {
        echo "$x <br>";
    }
?>
