<?php
 $x = 6;
    $y = 4;

    echo "Sum ",($x + $y),"<br>";
    echo "Diffrence ",($x - $y),"<br>";
    echo "Product ",($x * $y),"<br>";
    echo "Division ",($x / $y),"<br>";
?>
