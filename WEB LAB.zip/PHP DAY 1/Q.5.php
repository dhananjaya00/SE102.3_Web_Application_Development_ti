<?php
$fruits = array("apple", "banana", "orange");
foreach ($fruits as $fruit) {
  echo "$fruit <br>";
}
?>
