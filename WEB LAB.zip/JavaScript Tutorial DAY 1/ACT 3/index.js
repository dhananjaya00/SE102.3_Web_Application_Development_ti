function red() {
    document.bgColor = 'Red';
}
function green() {
    document.bgColor = 'green';
}
function blue() {
    document.bgColor = 'blue';
}