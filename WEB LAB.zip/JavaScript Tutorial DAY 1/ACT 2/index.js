let sum = 0;
for(let x = 1; x<=5; x++) {
    sum = parseInt(prompt('Enter '+ (x)+ ' Number'));
}
let avg = sum/5;

alert('Sum is: '+ sum+ '\nAverage is: '+ avg);