function q1() {
  alert("Alert");
}