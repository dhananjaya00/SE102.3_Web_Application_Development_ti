let inc = prompt('Enter NIC Number');

prompt('Your Birth Year is: '+inc.slice(0, 4));