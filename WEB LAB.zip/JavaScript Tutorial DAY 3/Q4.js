function password() {
  if (document.form.password.value === document.form.tr_password.value) {
    alert("Password are not same!");
  }
}
